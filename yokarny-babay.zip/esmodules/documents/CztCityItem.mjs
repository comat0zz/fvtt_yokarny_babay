/**
 * Extend the basic Item
 * @extends {Item}
 */
import { SYSTEM } from "../configs/system.mjs";

export default class CztCityItem extends Item {

};